#!/usr/bin/python
# -*- coding: utf-8 -*-

__version__ = '0.2.0'
version = __version__
VERSION = __version__
