
print "C.py"

all = ['name1']

def name1():
    pass
