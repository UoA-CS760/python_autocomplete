"""Re-run individual tasks within multiprocessing framework.
"""

def runfn(*args):
    print args
    raise NotImplementedError
