"""
Transactional version control for Django models.

Developed by Dave Hall.

<http://www.etianen.com/>
"""

from __future__ import unicode_literals


__version__ = VERSION = (1, 10, 2)
