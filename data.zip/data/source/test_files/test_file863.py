# Copyright (c) 2010, 2011, 2012 Yubico AB
# See the file COPYING for licence statement.

"""
Unit tests testing logic of the library.
These do not require a physical YubiKey to run.
"""
