#!/usr/bin/python
# -*- coding: utf-8 -*-
"""Testing configuration (imported by __init__.py)"""

sqldb = ":memory:"
