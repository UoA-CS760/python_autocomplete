"""
    twtxt
    ~~~~~

    Decentralised, minimalist microblogging service for hackers.

    :copyright: (c) 2016 by buckket.
    :license: MIT, see LICENSE for more details.
"""


__version__ = '1.3.0-dev'
