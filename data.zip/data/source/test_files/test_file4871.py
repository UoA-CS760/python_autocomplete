"""The tests for Alarm control panel platforms."""
