from corehq.apps.app_manager.fixtures.mobile_ucr import report_fixture_generator

__all__ = ['report_fixture_generator']
