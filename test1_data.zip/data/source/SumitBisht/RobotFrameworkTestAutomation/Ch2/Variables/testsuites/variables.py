# This file contains variable definitions
Weather = [ "London", "Cloudy", 25]
humidity = 75
MARKS = 65.5
DAYS = ["Monday", "Wednesday", "Friday", "Sunday"]
details = {'genre':'open-source','type':'test automation', 'pub':2013}