
class TextrankRuntimeError(RuntimeError):
    pass