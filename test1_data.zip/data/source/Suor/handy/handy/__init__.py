VERSION = (0, 5, 4)
__version__ = '.'.join(map(str, VERSION))
