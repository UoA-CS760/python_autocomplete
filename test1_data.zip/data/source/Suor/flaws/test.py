import sys

x = 1
y = 2

def f(n, uh=None):
    _def = None
    # import os as s
    # global h
    return y * n * h

# print x

# class A(Base):
#     def meth(self):
#         return self + 1

# default = 'hi'

# def g(x=default): # this is global
#     default = 10  # this is local
