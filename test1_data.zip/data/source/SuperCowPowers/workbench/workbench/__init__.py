''' Workbench: A scalable framework for security research and development teams. '''
__author__ = 'The Workbench Team'
__email__ = 'support@supercowpowers.com'
