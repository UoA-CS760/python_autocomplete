''' Workbench Server Version '''
__version_info__ = (0, 3, 6)  
__version__      = '.'.join(map(str, __version_info__))
