import sublime


HOST_PLATFORM = sublime.platform()

WINDOWS = 'windows'
LINUX = 'linux'
OSX = 'osx'
