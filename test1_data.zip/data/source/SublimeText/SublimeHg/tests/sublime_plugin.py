class Plugin(object):
    pass


class TextCommand(Plugin):
    pass


class WindowCommand(Plugin):
    pass


class EventListener(Plugin):
    pass
