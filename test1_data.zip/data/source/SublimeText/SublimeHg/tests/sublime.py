def packages_path():
    return 'XXX'
