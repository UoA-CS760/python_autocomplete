candidate_hash = {
    '2016': {'CRUZ, TED': {'cand_name': u'CRUZ, TED', 'cand_office': u'P', 'cand_office_district': u'', 'cand_id': 'P60006111', 'cand_pty_affiliation': u'REP', 'cand_office_st': u''}}
    }
