# coding: utf-8
""" Dummy Classes to make it possible to import
Sublime plugins for sphinx docs"""


class WindowCommand(object):
    pass


class TextCommand(object):
    pass


class EventListener(object):
    pass
